"use client";
import { useState, useEffect } from 'react';
type RefImg={id:string; url:string; preview:string; name:string};

export default function AririRunningHub(){
  const [model,setModel]=useState<'2.0'|'2.5'>('2.5');
  const [duration,setDuration]=useState(5);
  const [prompt,setPrompt]=useState('Wanita @img1 berjalan di sawah Bali cinematic sunset, konsisten wajah 100%');
  const [refs,setRefs]=useState<RefImg[]>([]);
  const [apiKey,setApiKey]=useState('');
  const [useOwnKey,setUseOwnKey]=useState(false);
  const [loading,setLoading]=useState(false);
  const [videoUrl,setVideoUrl]=useState('');
  const [log,setLog]=useState<string[]>([]);
  const maxDuration=model==='2.0'?15:30;

  const handleFiles=async(files:FileList|null)=>{
    if(!files) return;
    const formData=new FormData();
    Array.from(files).slice(0,10-refs.length).forEach(f=>formData.append('files',f));
    try{
      const res=await fetch('/api/upload',{method:'POST', body:formData});
      const data=await res.json();
      if(data.urls){
        const newRefs=data.urls.map((u:any)=>({id:Math.random().toString(36).slice(2), url:u.url, preview:u.url, name:u.name}));
        setRefs(prev=>[...prev,...newRefs].slice(0,10));
        setLog(prev=>[...prev, `> Uploaded ${newRefs.length} foto ke Blob`]);
        return;
      }
    }catch(e){ console.log(e); }
  };

  const handleGenerate=async()=>{
    if(refs.length===0){ alert('Upload minimal 1 foto untuk Image to Video, atau kosongkan untuk Text to Video'); }
    setLoading(true);
    setLog([`> Model Seedance ${model}`, `> Durasi ${duration}s / max ${maxDuration}s`, `> Refs ${refs.length}/10`, `> Endpoint: RunningHub /bytedance/seedance-${model}-global...`, `> API Key: ${useOwnKey?'Input User':'Vercel Env (RUNNINGHUB_API_KEY)'}`]);
    try{
      const res=await fetch('/api/generate',{method:'POST', headers:{'Content-Type':'application/json'}, body:JSON.stringify({prompt,duration,model,resolution:'720p',aspect_ratio:'adaptive',image_urls:refs.map(r=>r.url), generateAudio:true, apiKeyFromUser: useOwnKey?apiKey:undefined})});
      const data=await res.json();
      if(!res.ok) throw new Error(data.error+' '+JSON.stringify(data.detail||''));
      setLog(prev=>[...prev, `> TaskId: ${data.taskId}`, `> Status: ${data.status}`, `> Video: ${data.video?.url || data.url}`]);
      setVideoUrl(data.video?.url || data.url || '');
    }catch(e:any){ setLog(prev=>[...prev, `> ERROR: ${e.message}`]); }
    finally{ setLoading(false); }
  };

  return (
    <div className="min-h-screen bg-[#0f0f0f] text-white p-4">
      <div className="max-w-5xl mx-auto">
        <h1 className="text-3xl font-bold bg-gradient-to-r from-[#e8dcc8] to-purple-400 bg-clip-text text-transparent">Ariri Studio - RunningHub Edition</h1>
        <p className="text-sm text-[#888] mt-2">Pakai API Key dari runninghub.ai/id/call-api/bill-task?tab=keys&type=consumer</p>

        <div className="grid md:grid-cols-2 gap-6 mt-6">
          <div className="bg-[#1a1a1a] rounded-2xl p-5 border border-[#222] space-y-4">
            <div className="bg-[#111] border border-[#333] rounded-xl p-3">
              <div className="flex justify-between items-center">
                <span className="text-xs font-bold">🔑 RUNNINGHUB API KEY (Milik Kamu)</span>
                <button onClick={()=>setUseOwnKey(!useOwnKey)} className={`text-[11px] px-3 py-1 rounded-full ${useOwnKey?'bg-[#e8dcc8] text-black':'bg-[#222] text-[#888]'}`}>{useOwnKey?'Input Manual':'Vercel Env'}</button>
              </div>
              {useOwnKey ? <input type="password" value={apiKey} onChange={e=>setApiKey(e.target.value)} placeholder="Paste key dari RunningHub Consumer" className="w-full mt-2 bg-black border border-[#333] rounded-lg p-2.5 text-xs" /> : <div className="mt-2 text-[11px] text-[#888] bg-[#1a1a1a] p-2 rounded border border-[#222]">Akan pakai <code className="text-[#e8dcc8]">RUNNINGHUB_API_KEY</code> dari Vercel Env Variables. Ambil di link yang kamu kasih.</div>}
            </div>

            <select value={model} onChange={e=>{setModel(e.target.value as any); if(e.target.value==='2.0'&&duration>15)setDuration(15);}} className="w-full bg-[#151515] border border-[#2a2a2a] rounded-xl p-3 text-sm">
              <option value="2.0">Seedance 2.0 - Max 15s</option>
              <option value="2.5">Seedance 2.5 - Max 30s + 10 Ref ⭐</option>
            </select>

            <div>
              <label className="text-xs text-[#aaa]">Durasi {duration}s / Max {maxDuration}s</label>
              <input type="range" min="4" max={maxDuration} value={duration} onChange={e=>setDuration(parseInt(e.target.value))} className="w-full accent-[#e8dcc8]" />
            </div>

            <textarea value={prompt} onChange={e=>setPrompt(e.target.value)} placeholder="Prompt... pakai @img1 @img2 untuk referensi" className="w-full bg-[#151515] border border-[#2a2a2a] rounded-xl p-3 text-sm min-h-[100px]" />

            <div className="bg-black/40 rounded-xl p-3 border border-white/5">
              <div className="text-[11px] font-bold">Foto Referensi Max 10 - {refs.length}/10</div>
              <div className="grid grid-cols-5 gap-2 mt-2">
                {refs.map((r,i)=><div key={r.id} className="relative aspect-square rounded-lg overflow-hidden border border-[#2a2a2a]"><img src={r.preview} className="w-full h-full object-cover" /><button onClick={()=>setRefs(prev=>prev.filter(x=>x.id!==r.id))} className="absolute top-0 right-0 bg-red-600 text-[9px] px-1">x</button><div className="absolute bottom-0 w-full bg-black/60 text-[8px] text-center">IMG{i+1}</div></div>)}
                {refs.length<10 && <label className="aspect-square border border-dashed border-[#333] rounded-lg flex items-center justify-center cursor-pointer text-xs">+<input type="file" multiple accept="image/*" className="hidden" onChange={e=>handleFiles(e.target.files)} /></label>}
              </div>
            </div>

            <button onClick={handleGenerate} disabled={loading} className="w-full bg-[#e8dcc8] text-black font-bold py-3.5 rounded-xl disabled:opacity-50">{loading?'Generating...':'Generate Video'}</button>
          </div>

          <div className="bg-[#1a1a1a] rounded-2xl p-5 border border-[#222]">
            <div className="aspect-video bg-black rounded-xl flex items-center justify-center overflow-hidden">
              {videoUrl ? <video src={videoUrl} controls autoPlay className="w-full h-full" /> : <span className="text-xs text-[#555]">Video hasil akan muncul di sini<br/>RunningHub task akan disimpan 24 jam, download segera</span>}
            </div>
            <div className="mt-4 bg-black rounded-lg p-3 font-mono text-[11px] text-green-400 h-[200px] overflow-auto">
              {log.map((l,i)=><div key={i}>{l}</div>)}
            </div>
          </div>
        </div>

        <div className="mt-8 bg-[#1a1a1a] border border-[#222] rounded-xl p-4 text-xs text-[#888]">
          <b className="text-white">Cara ambil API Key RunningHub (punya kamu):</b><br/>
          1. Buka https://www.runninghub.ai/id/call-api/bill-task?tab=keys&type=consumer<br/>
          2. Tab Keys -> Type Consumer -> Copy API Key<br/>
          3. Di Vercel -> Settings -> Environment Variables -> Name: RUNNINGHUB_API_KEY, Value: key kamu -> Save -> Redeploy<br/>
          Endpoint: /openapi/v2/bytedance/seedance-2.0-global/text-to-video (max 15s) dan /bytedance/seedance-2.5-global-token/multimodal-video (max 30s, 10 ref)
        </div>
      </div>
    </div>
  )
}

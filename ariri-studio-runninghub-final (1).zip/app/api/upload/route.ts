import { put } from '@vercel/blob';
import { NextResponse } from 'next/server';
export async function POST(req: Request) {
  try {
    const formData = await req.formData();
    const files = formData.getAll('files') as File[];
    const uploaded=[];
    for(const file of files.slice(0,10)){
      const blob=await put(`ariri/${Date.now()}-${file.name}`, file, {access:'public', addRandomSuffix:true});
      uploaded.push({name:file.name, url:blob.url});
    }
    return NextResponse.json({urls:uploaded});
  } catch(e:any){ return NextResponse.json({error:e.message}, {status:500}); }
}

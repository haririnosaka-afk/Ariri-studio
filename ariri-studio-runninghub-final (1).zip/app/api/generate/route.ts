import { NextRequest, NextResponse } from 'next/server';

export async function POST(req: NextRequest) {
  try {
    const body = await req.json();
    const { prompt, duration, model, resolution, aspect_ratio, image_urls, generateAudio, apiKeyFromUser } = body;

    const maxDuration = model === '2.0' ? 15 : 30;
    const finalDuration = Math.min(Math.max(parseInt(duration)||5, 4), maxDuration);

    // AMBIL API KEY RUNNINGHUB KAMU
    const RH_KEY = (apiKeyFromUser && apiKeyFromUser.trim() !== '') ? apiKeyFromUser.trim() : process.env.RUNNINGHUB_API_KEY;
    const BASE_URL = process.env.RUNNINGHUB_BASE_URL || 'https://www.runninghub.ai/openapi/v2';
    
    if(!RH_KEY){
      return NextResponse.json({error:'RUNNINGHUB_API_KEY tidak ditemukan. Set di Vercel Env Variables. Ambil di https://www.runninghub.ai/id/call-api/bill-task?tab=keys&type=consumer'}, {status:400});
    }

    const refs: string[] = (image_urls || []).slice(0,10).filter((u:string)=>u);

    // TENTUKAN ENDPOINT RUNNINGHUB
    let endpoint = '';
    let payload: any = {
      prompt: prompt || 'Cinematic video',
      duration: finalDuration.toString(),
      resolution: resolution || '720p',
      ratio: aspect_ratio?.includes('Auto') ? 'adaptive' : (aspect_ratio || 'adaptive'),
      generateAudio: generateAudio || true,
      seed: -1
    };

    if(refs.length===0){
      // Text to Video
      endpoint = model==='2.0' ? '/bytedance/seedance-2.0-global/text-to-video' : '/bytedance/seedance-2.5-global-token/text-to-video';
    }else if(refs.length===1){
      // Image to Video
      endpoint = model==='2.0' ? '/bytedance/seedance-2.0-global/image-to-video' : '/bytedance/seedance-2.5-global-token/image-to-video';
      payload.image_url = refs[0];
      payload.first_frame = refs[0];
    }else{
      // Multimodal / Reference - 2-10 foto
      endpoint = model==='2.0' ? '/bytedance/seedance-2.0-global/reference-to-video' : '/bytedance/seedance-2.5-global-token/multimodal-video';
      payload.image_urls = refs;
      payload.reference_images = refs;
      payload.images = refs;
    }

    // SUBMIT TASK KE RUNNINGHUB
    const submitRes = await fetch(`${BASE_URL}${endpoint}`, {
      method:'POST',
      headers:{
        'Authorization': `Bearer ${RH_KEY}`,
        'Content-Type':'application/json'
      },
      body: JSON.stringify(payload)
    });

    const submitData = await submitRes.json();
    if(!submitRes.ok){
      return NextResponse.json({error:'Gagal submit ke RunningHub', detail:submitData, endpoint: BASE_URL+endpoint, payload}, {status: submitRes.status});
    }

    const taskId = submitData.taskId || submitData.task_id || submitData.data?.taskId;
    if(!taskId){
      // Beberapa endpoint RunningHub langsung return video
      return NextResponse.json(submitData);
    }

    // POLLING HASIL - RunningHub pakai /openapi/v2/query
    let result = null;
    for(let i=0;i<90;i++){
      await new Promise(r=>setTimeout(r,3000));
      const queryRes = await fetch(`${BASE_URL}/query`, {
        method:'POST',
        headers:{
          'Authorization': `Bearer ${RH_KEY}`,
          'Content-Type':'application/json'
        },
        body: JSON.stringify({ taskId })
      });
      const queryData = await queryRes.json();
      // Status: QUEUED, RUNNING, SUCCESS, FAILED
      if(queryData.status==='SUCCESS' || queryData.results){
        result = queryData;
        break;
      }
      if(queryData.status==='FAILED'){
        return NextResponse.json({error:'Generate gagal di RunningHub', detail:queryData}, {status:500});
      }
    }

    if(!result){
      const finalRes = await fetch(`${BASE_URL}/query`, {
        method:'POST',
        headers:{ 'Authorization': `Bearer ${RH_KEY}`, 'Content-Type':'application/json' },
        body: JSON.stringify({ taskId })
      });
      result = await finalRes.json();
    }

    // Normalisasi output biar frontend sama
    const videoUrl = result.results?.[0]?.url || result.results?.video_url || result.video_url || result.url || '';
    return NextResponse.json({ ...result, video: { url: videoUrl }, url: videoUrl, taskId });

  } catch(e:any){
    return NextResponse.json({error:e.message}, {status:500});
  }
}

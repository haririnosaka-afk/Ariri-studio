# Ariri Studio - RunningHub Edition

Pakai API Key dari https://www.runninghub.ai/id/call-api/bill-task?tab=keys&type=consumer

## Setup
1. Dapatkan API Key RunningHub Consumer
2. Deploy ke Vercel, set Env: RUNNINGHUB_API_KEY = key kamu, RUNNINGHUB_BASE_URL = https://www.runninghub.ai/openapi/v2
3. Aktifkan Vercel Blob untuk upload 10 foto ref

## Endpoint RunningHub
- Text to Video: /bytedance/seedance-2.0-global/text-to-video (4-15s)
- Image to Video: /bytedance/seedance-2.0-global/image-to-video
- 2.5 Text to Video: /bytedance/seedance-2.5-global-token/text-to-video (4-30s)
- 2.5 Multimodal (10 ref): /bytedance/seedance-2.5-global-token/multimodal-video

Polling: POST /openapi/v2/query dengan {taskId}
